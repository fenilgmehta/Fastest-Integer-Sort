myFolder='03_run_temp'
outputZipFile="output.zip"

zip -r "${outputZipFile}" "${myFolder}"
