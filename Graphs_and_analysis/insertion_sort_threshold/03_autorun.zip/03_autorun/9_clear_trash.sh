folderName='.'


for i in $(find ${folderName} | sort -r)
do
    # this if statement will check if ${i} is a directory or not
    # if ${i} is a file, then the if block will execute
    if ! [[ -d $i ]]
    then
        # print file name
        # echo $i


        # print file information before modification
        # stat $i


        # variable initialization
        fileName=$i
        ch='#'


        # this module will generate ${replaceStr} of the ((length = 2^n)) such that ((2^n < k))
        k=`wc -c ${fileName} | awk '{print $1}'`
        replaceStr='${ch}'
        while [[ `echo -n "${replaceStr}" | wc -c` -le k ]]
        do
            replaceStr="${replaceStr}${replaceStr}"
        done

        # this module will generate ${replaceStr} of ((length = k))
        # j=0
        # k=`wc -c ${fileName} | awk '{print $1}'`
        # replaceStr="${ch}${ch}"
        # while [[ j -le k ]]
        # do
           #  replaceStr="${replaceStr}${ch}"
           #  ((j=j+1))
        # done


        echo ${replaceStr} > ${fileName}


        # print file information after modification
        # stat $i
    fi
done

rm -rf ${folderName}

# this will create a trash file with '#' as it content, file size for 1..15 is 2MB
# echo -n '#' > trash.txt && echo -n '#' > trash1.txt
# for i in {1..15}
# do
#     cat trash.txt >> trash1.txt && cat trash1.txt >> trash.txt
# done
