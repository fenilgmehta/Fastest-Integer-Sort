# this files is used to perform many tests using other modules

myFolder="runFolder"
outputZipFile="output.zip"


echo -e "\n######################"
echo "       Started"
echo "######################"


# INPUT SYNTAX for "runProcessesInParallel.sh"
# fileNameForCompilation, minArrayLength, arrDiff, testCases, insertionSortThreshold
cd "${myFolder}"
# . runProcessesInParallel.sh threshold_insertion_merge.cpp 1 75 100000 -1 &&           # done
# . runProcessesInParallel.sh threshold_insertion_merge.cpp 76 895 100000 75 &&         # done
# . runProcessesInParallel.sh threshold_insertion_merge.cpp 896 1360 100000 50 &&       # done
. runProcessesInParallel.sh threshold_insertion_merge.cpp 1361 2000 100000 50

. runProcessesInParallel.sh threshold_insertion_quick.cpp 1 50 100000 -1
. runProcessesInParallel.sh threshold_insertion_quick.cpp 51 2000 100000 50

# . runProcessesInParallel.sh insertion_merge.cpp 1 200 100000
# . runProcessesInParallel.sh insertion_quick.cpp 1 200 100000
# . runProcessesInParallel.sh insertion_merge.cpp 201 2000 100000 200
# . runProcessesInParallel.sh insertion_quick.cpp 201 2000 100000 200


#######################################################################################################################
#######################################################################################################################
#######################################################################################################################


sleepTime=10

echo -n "Waiting for the testcases to finish running"
while [[ `ps -e | grep "1_c_.*" | wc -l` -gt 0 ]]; do echo -n "." && sleep ${sleepTime}; done


# print the list of files with (lines < $minLines)
minLines=5
countFiles=0
errorneousFiles="15_files_with_lines_less_than_${minLines}.txt"
echo -e "\n\n"
echo "############################################################################################"
echo "checking files with (lines < ${minLines}) are:"
echo "############################################################################################"
for i in `ls stats_* | sort -V`;
do
    temp_lineCount=`cat $i | wc -l`
    if [[ temp_lineCount -lt minLines ]]
    then
        ((countFiles=countFiles+1))
        echo ${countFiles}") " $i
    fi
done >> ${errorneousFiles}

# delete ${errorneousFiles} if it is empty
if [[ `wc -c ${errorneousFiles} | awk '{print $1}'` -eq 0 ]]
then
    rm ${errorneousFiles}
fi


echo -e "\n######################"
echo "   Finished running"
echo "######################"
echo "  Performing cleanup"
echo "######################"

cd ..
zip -r "${outputZipFile}" "${myFolder}"

. permanentlyDeleteFilesAndFolders.sh "${myFolder}"

echo -e "\n######################"
echo "   Cleanup complete"
echo "######################"
