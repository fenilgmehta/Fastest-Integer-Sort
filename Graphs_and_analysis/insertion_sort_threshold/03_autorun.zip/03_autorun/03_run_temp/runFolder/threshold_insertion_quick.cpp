#include <iostream>
#include <cstdint>

#include <iomanip>
#include <algorithm>
#include <chrono>

//#################################################
#pragma clang diagnostic push
#pragma ide diagnostic ignored "OCUnusedGlobalDeclarationInspection"
#pragma ide diagnostic ignored "OCUnusedMacroInspection"
#pragma ide diagnostic ignored "OCDFAInspection"
#pragma ide diagnostic ignored "OCSimplifyInspection"

//#################################################
#define db1(x) cerr << "\nDebug: " << setw(30) << left << #x << " = " << (x);
#define db2(x, y) cerr << "\nDebug: " << #x << " = " << (x) << ",   " << #y << " = " << (y);
#define db3(x, y, z) cerr << "\nDebug: " << #x << " = " << (x) << ",   " << #y << " = " << (y) << ",   " << #z << " = " << (z);
#define dbArrSize(arr, size) cerr << "\nDebug: " << #arr << " [" << 0 << " : " << ((size)-1) << "] = "; for(int64_t i = 0; i < (size); i++) cerr << (arr)[i] << ", ";
#define dbArrLimit(arr, l, h) cerr << "\nDebug: " << #arr << " [" << (l) << " : " << (h) << "] = "; for(int64_t i = (l); i <= (h); i++) cerr << (arr)[i] << ", ";
#define endl '\n'
#define min(_a, _b) ((_a) < (_b)) ? (_a) : (_b)

//#################################################
using namespace std;
using namespace std::chrono;

//#################################################
#define rangeup(_i, _startLimit, _endLimit) for(int64_t (_i) = (_startLimit); (_i) < (_endLimit); (_i)++)
#define rangeupStep(_i, _startLimit, _endLimit, _step) for(int64_t (_i) = (_startLimit); (_i) < (_endLimit); (_i)+=(_step))
const int columnWidth = 15;

//int INSERTION_SORT_THRESHOLD = 25;
//int MERGE_SORT_THRESHOLD = 135;
int64_t INSERTION_SORT_THRESHOLD = 0;
int64_t MERGE_SORT_THRESHOLD = 0;


int64_t THRESHOLD_INSERTION_FOR_MERGE[] = {};
int64_t THRESHOLD_INSERTION_FOR_QUICK[] = {};
int64_t THRESHOLD_QUICK_FOR_MERGE[] = {};
int64_t THRESHOLD_MERGE_FOR_QUICK[] = {};

int64_t THRESHOLD_MERGE_FOR_RADIX_int32[] = {};
int64_t THRESHOLD_MERGE_FOR_RADIX_long64[] = {};
int64_t THRESHOLD_QUICK_FOR_RADIX_int32[] = {};
int64_t THRESHOLD_QUICK_FOR_RADIX_long64[] = {};

//##################################################################################################
//##################################################################################################
//##################################################################################################
// INSERTION SORT
template<typename T>
void insertion_sort(T arr[], const int64_t &low, const int64_t &high) {
    T key;
    int64_t i, j;

    for (i = low + 1; i <= high; i++) {
        key = arr[i];
        j = i - 1;

        // Move elements of arr[low...i-1], that are greater than key, to one position ahead of their current position
        while (j >= low && arr[j] > key) {
            arr[j + 1] = arr[j];
            j--;
        }
        arr[j + 1] = key;
    }
}

//#################################################
// Merge sort
template<typename T>
void merge(T arr[], const int64_t &low, const int64_t &mid, const int64_t &high) {
    // Q points to the END of FIRST subarray
    int64_t leftArray_length = mid - low + 1, rightArray_length = high - mid;
    T L[leftArray_length];
    T R[rightArray_length];

    for (int64_t i = low, j = 0; j < leftArray_length; i++, j++) {
        L[j] = arr[i];
    }
    for (int64_t i = mid + 1, j = 0; j < rightArray_length; i++, j++) {
        R[j] = arr[i];
    }

    for (int64_t i = 0, j = 0, k = low; k >= low && k <= high; k++) {
        if (i < leftArray_length && j < rightArray_length) {
            if (L[i] < R[j]) {
                arr[k] = L[i];
                i++;
            } else {
                arr[k] = R[j];
                j++;
            }
        } else if (i == leftArray_length) {
            arr[k] = R[j];
            j++;
        } else if (j == rightArray_length) {
            arr[k] = L[i];
            i++;
        }
    }
}

template<typename T>
void merge_sort(T arr[], const int64_t &low, const int64_t &high) {
    if (low >= high) return;

    if ((high - low) < INSERTION_SORT_THRESHOLD) {
        insertion_sort<T>(arr, low, high);
        return;
    }

    int64_t mid = (low + high) >> 1;    // int64_t mid = (low + high) / 2;

    if ((mid - low) < INSERTION_SORT_THRESHOLD) {
        insertion_sort<T>(arr, low, mid);
    } else {
        merge_sort<T>(arr, low, mid);
    }

    if ((high - mid - 1) < INSERTION_SORT_THRESHOLD) {
        insertion_sort<T>(arr, mid + 1, high);
    } else {
        merge_sort<T>(arr, mid + 1, high);
    }

    //merge<T>(arr, low, mid, high);
    merge(arr + low, arr + mid + 1, arr + mid + 1, arr + high + 1, arr + low);
}

//#################################################
// Quick sort
template<typename T>
void quick_sort(T arr[], const int64_t &low, const int64_t &high) {
    if (low >= high) return;

    if ((high - low) < INSERTION_SORT_THRESHOLD) {
        insertion_sort<T>(arr, low, high);
        return;
    }

    T mid = (low + high) >> 1;
    if (arr[mid] > arr[low]) swap(arr[mid], arr[low]);
    if (arr[mid] > arr[high]) swap(arr[mid], arr[high]);
    if (arr[low] > arr[high]) swap(arr[low], arr[high]);
    T pivot = arr[low];    // pivot

    int64_t i = low;
    int64_t j = high + 1;

    while (i < j) {

        // find item on lo to swap
        while (arr[++i] < pivot) {
            if (i == high) break;
        }

        // find item on hi to swap
        while (pivot < arr[--j]) {
            if (j == low) break;      // redundant since arr[low] acts as sentinel
        }

        // check if pointers cross
        if (i < j) swap(arr[i], arr[j]);
    }

    // put partitioning item pivot at arr[j]
    swap(arr[low], arr[j]);

    if ((j - 1 - low) < INSERTION_SORT_THRESHOLD) insertion_sort<T>(arr, low, j - 1);
    else quick_sort(arr, low, j - 1);

    if ((high - j - 1) < INSERTION_SORT_THRESHOLD) insertion_sort<T>(arr, j + 1, high);
    else quick_sort(arr, j + 1, high);
}

//##################################################################################################
//##################################################################################################
//##################################################################################################

template<typename T>
bool isSortedAscending(const T arr[], const int64_t &low, const int64_t &high) {
    for (int64_t i = low; i < high; i++) {
        if (arr[i] > arr[i + 1]) return false;
    }
    return true;
}

template<typename T>
bool isNotSorted(const T arr[], const int64_t &low, const int64_t &high) {
    return !(isSortedAscending(arr, low, high));
}

template<typename T>
int64_t maxIndex(const T arr[], const int64_t &size) {
    int64_t index = 0;
    rangeup(i, 1, size) if (arr[index] < arr[i]) index = i;

    return index;
}

template<typename T>
int64_t minIndex(const T arr[], const int64_t &size) {
    int64_t index = 0;
    rangeup(i, 1, size) if (arr[index] > arr[i]) index = i;

    return index;
}
//##################################################################################################
#define startTime wmemcpy((wchar_t *) arr, (wchar_t *) baseArray, (int64_t) arrayLength); start = high_resolution_clock::now();
#define endTime stop = high_resolution_clock::now(); duration = duration_cast<nanoseconds>(stop - start);
#define addTimeData(_arrName, _indexName) _arrName[_indexName] += duration.count();
#define checkSorting(_arr, _arrayLength) if (isNotSorted<int>(_arr, 0, (_arrayLength) - 1)) cout << "\nERROR: array is not sorted\n";
#define printTimeTaken cout << endl << setw(columnWidth) << duration.count();
#define time(_i) db1(_i);
#define avgTime(_i) db1((_i) / testCases);

template<typename T>
void myMethod1(T arr[], const int64_t &arrayLength) {

}

int main() {
    // Generate Random values
    auto f = []() -> int { return rand() % 2147483647; };

    auto start = high_resolution_clock::now();      // Get starting time
    auto stop = start;      // Get ending time
    nanoseconds duration;   // Get duration. Subtract start time point to get duration. To cast it to proper unit use duration cast method

    int64_t minArrayLength = 0, minMaxArrayLengthDiff = 0, testCases = 0, insertionThresholdUser = -1;

    cout << "Input: (minArrayLength, minMaxDiff, testCases, insertionThresholdUser;) = ";
    cin >> minArrayLength >> minMaxArrayLengthDiff >> testCases >> insertionThresholdUser;
    cout << endl;
    int64_t maxArrayLength = minArrayLength + minMaxArrayLengthDiff;

    rangeup(arrayLength, minArrayLength, maxArrayLength + 1) {
        cout << "#####################################################################";
        db1(arrayLength);
        db1(testCases)

        int baseArray[arrayLength];     // used to store the random array generated
        int arr[arrayLength];           // used to check sorting time, it will the values from the baseArray

        const int64_t sortingTechniques = arrayLength + 2;

        int64_t timeArrLength = 1 + ((insertionThresholdUser == -1) ? arrayLength : insertionThresholdUser);   // here min is a macro
        // int64_t timeArrLength = 3;   // here min is a macro
        // int64_t timeArrLength = min(3, (int64_t) (sortingTechniques * factor)) + 1;   // here min is a macro

        int64_t timeArr[timeArrLength] = {};             // used to store the time taken for a particular sorting technique
        int64_t bestThreshold[timeArrLength] = {};       // used to keep track of the best THRESHOLD

        rangeup(__, 0, testCases) {
            // Fill up the array
            generate(baseArray, baseArray + arrayLength, f);    // generate shuffled array
            int64_t timeArrIndex = 0;       // index to insert data in timeArr

            rangeup(m, 0, timeArrLength) {
                INSERTION_SORT_THRESHOLD = m;
                startTime
                quick_sort(arr, 0, arrayLength - 1);
                endTime
                checkSorting(arr, arrayLength)
                timeArr[timeArrIndex++] = duration.count();
            }

            //#################################################
            bestThreshold[minIndex(timeArr, timeArrLength)]++;
        }


        //dbArrSize(bestThreshold, sortingTechniques);
        dbArrSize(bestThreshold, timeArrLength);

        int64_t maxSpeedIndex = maxIndex(bestThreshold, timeArrLength);
        cout << endl;
        db1(bestThreshold[maxSpeedIndex])
        db1(bestThreshold[maxSpeedIndex] * 100.0 / testCases)

        cout << endl;
        db1(maxSpeedIndex)
        // db1(maxSpeedIndex - 1)

        cout << endl << endl;
    }

    cout << endl;
    return 0;
}

#pragma clang diagnostic pop
