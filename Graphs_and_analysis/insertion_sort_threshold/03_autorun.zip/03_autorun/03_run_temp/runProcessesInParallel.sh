#!/bin/bash
# input format: minArrayLength, arrayLengthDiff, testCases, insertionThreshold

#########################################################################################
# START variable declarations

# this will provide the .cpp to be compiled and run many processes on the output object file
cppFileName=$1; shift
objFileName="${cppFileName%.*}"

# this tells the start array length of the process
arrayLength=$1; shift
# arrayLength=456

# this value denotes the arrayLength for which the script should end
maxArrayLength=$1; shift
# maxArrayLength=500

# arrLength=501 -> 1000 , testCases=50000   , factor=0.2
# arrLength=186 -> 300  , testCases=500000  , factor=0.5
# arrLength=151 -> 250  , testCases=2000000 , factor=0.5
testCases=$1; shift
# factor=$1; shift
insertionThreshold=-1
insertionThreshold=$1; shift


# do NOT modify this
arrayLengthDiff=0

availableCPUcores=`nproc --all`

sleepTime=1

# END variable declarations
#########################################################################################

# WAIT till there are more than ${maxRunningProcesses} processes for sorting are running
((maxRunningProcesses = availableCPUcores * 2 / 3))
while [[ `ps -e | grep "1_c_.*" | wc -l` -gt maxRunningProcesses ]]; do echo -n "." && sleep ${sleepTime}; done

echo "############################################################################################"
echo "                                        START"
echo "############################################################################################"
echo "arrayLength = ${arrayLength}"
echo "maxArrayLength = ${maxArrayLength}"
# echo "arrayLengthDiff = ${arrayLengthDiff}"
echo "testCases = ${testCases}"
# echo "factor = ${factor}"

echo -e "\navailable CPU cores = ${availableCPUcores}\n"

sleep 1

echo "############################################################################################"
echo "The process is running..."
echo "############################################################################################"


g++ -std=c++14 ${cppFileName} -o ${objFileName}


while [[ arrayLength -le maxArrayLength ]]
do
    if [[ `ps -e | grep "1_c_.*" | grep -v grep | wc -l` -lt availableCPUcores ]]
    then
        echo -e "\n\n"
        fileStr="1_c_${objFileName}_${arrayLength}_${testCases}.out"
        inputStr="${arrayLength} ${arrayLengthDiff} ${testCases} ${insertionThreshold}"
        outputStr="stats_${objFileName}_${arrayLength}_${testCases}.txt"
        cp "${objFileName}" "${fileStr}"
        echo "inputStr = '$inputStr'"
        echo "outputStr = '$outputStr'"
        # nice --19 ./${fileStr} <<< ${inputStr} &> ${outputStr} && . permanentlyDeleteFilesAndFolders.sh ${fileStr} &
        ./${fileStr} <<< ${inputStr} &> ${outputStr} && . permanentlyDeleteFilesAndFolders.sh ${fileStr} &
        echo "arrayLength = ${arrayLength}"
        ((arrayLength = arrayLength + 1))
    else
        sleep ${sleepTime}
    fi
done

. permanentlyDeleteFilesAndFolders.sh ${objFileName}


echo -e "\n\n"
echo "############################################################################################"
echo "                      Finished runProcessesInParallel.sh script"
echo "############################################################################################"



# # KILL all the sorting processes running
# for i in `ps -e | grep "1_c_.*" | awk '{print $1}'`; do kill -9 $i; done


# # this will delete all the object files
# ls c_*[0-9][0-9]*.out
# rm c_*[0-9][0-9]*.out


##################################################################


# # this block is used to combine the multiple files generated from different processes
# outputFileName="1_stats_.txt"
# # delete first line of each .txt file
# for i in `ls *.txt | sort -V`; do sed -i '1d' $i; done
# # delete last line of each .txt file
# for i in `ls *.txt | sort -V`; do sed -i '$ d' $i; done
# # combine all .txt files in current folder and write to ${outputFileName}
# for i in `ls *.txt | sort -V`; do cat $i >> $outputFileName; done


# # this will select particular lines
# ls -v1 stats_comp_insertion_merge_* | xargs cat | grep "Debug: maxSpeedIndex"

##################################################################
# change priority of a process

# renice -n -19 -p 3534
# nice -n 5 perl test.pl

# nice --19 ./c1 <<< "300 200 50000 0.3333333"
# nice --19 ./c2 <<< "540 100 50000 0.2"

# nice --19 ./c3 <<< "128 100 500000 0.6"

# nice --19 ./c4 <<< "75 100 2000000 1"

# ps -e | grep "1_c.*"
# ps -e | grep "1_c.*" | awk '{print $1}'

# this will set the priority of all the sorting processes running to max
# for i in `ps -e | grep "1_c.*" | awk '{print $1}'`
# do
#     renice -n -19 -p ${i}
# done

##################################################################
