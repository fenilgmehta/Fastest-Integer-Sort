. permanentlyDeleteFilesAndFolders.sh "."

p=`pwd`
rm -rf ${p}