file_mainScript="mainScript.sh"
file_processManager="runProcessesInParallel.sh"
file_myDelete="permanentlyDeleteFilesAndFolders.sh"

cp "${file_processManager}" "./runFolder"
cp "${file_myDelete}" "./runFolder"

. ${file_mainScript}

# cp "${1_mainScript.sh}" "mainFolder"
# cp "${file_processManager}" "./mainFolder/runFolder"
# cp "${file_myDelete}" "mainFolder"
# cp "${file_myDelete}" "./mainFolder/runFolder"

